#ifndef VERSION_H_
#define VERSION_H_

#define VERSION "Pre release 0.1.0"
#define MIN_FW 474
#define MAX_FW 1402

#endif
